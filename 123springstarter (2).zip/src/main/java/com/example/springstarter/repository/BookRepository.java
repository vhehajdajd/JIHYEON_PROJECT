package com.example.springstarter.repository;

import com.example.springstarter.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository //이건 생략해도 됨
public interface BookRepository extends JpaRepository<Book, Long> {
    // 1. 기본적으로 JpaRepository에서 제공해주는 메서드를 사용
    // 2. 직접 메서드를 만들 수도 있음
}
