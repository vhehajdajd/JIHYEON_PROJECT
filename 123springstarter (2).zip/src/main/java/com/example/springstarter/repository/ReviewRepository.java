package com.example.springstarter.repository;

import com.example.springstarter.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    // 평균 평점 조회
    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.book.id =:book_id")
    public Double findAverageRatingByBookId(@Param("book_id") Long book_id);

    // 리뷰 삭제
    /*
        * cascade = CascadeType.ALL + fetch = FetchType.EAGER 환경에서
        기본 deleteById()는 영속성 켄텍스트 충돌 발생함.
        --> @Query()로 직접 DELETE SQL 실행하여 우회함
        * DELETE/UPDATE처럼 데이터를 변경하는 쿼리에는 반드시 @Modifying을 붙여야 함
     */
    @Modifying
    @Query("DELETE FROM Review r WHERE r.id = :id")
    void deleteReviewDirectly(@Param("id") Long id);
}
