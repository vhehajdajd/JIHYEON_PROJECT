package com.example.springstarter.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String subject;
    private int price;
    private String author;
    private int page;
    private LocalDateTime createdAt;    // 클래스: 카멜표기법 → DB(테이블): 스네이크(언더바)

    /*
        @OneToMany( 			하나의 Book에 여러 Review가 달림
	       mappedBy			    Review의 "book" 필드가 FK를 가진 관계의 주인
	       CascadeTypeALL		Book 삭제 시 연관된 Review도 자동 삭제
	       FetchType.EAGER		Book 조회 시 Review도 즉시 함께 가져옴
        )
     */

    @OneToMany(mappedBy = "book", cascade = CascadeType.ALL, fetch = FetchType.EAGER)    //"book" = Review 엔티티 클래스의 book
    private List<Review> reviews;
}
