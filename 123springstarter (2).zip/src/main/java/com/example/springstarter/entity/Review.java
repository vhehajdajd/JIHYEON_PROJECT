package com.example.springstarter.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Setter
@Getter
@NoArgsConstructor
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;                //리뷰 일련 번호 (자동증가, PK)
    private String content;         //리뷰 내용
    private int rating;             //평점
    private LocalDateTime createdAt; //작성일자


    /*
        @ManytoOne( 			여러 Review가 하나의 Book에 속함
        )
        @JoinColumn(			review 테이블에서 book_id 컬럼을 FK로 설정
        )
     */
    @ManyToOne
    @JoinColumn(name = "book_id", referencedColumnName = "id", nullable = false)   //book_id = 조인컬럼이 추가? // id = review의 id?
    private Book book;      //book = 필드


}
