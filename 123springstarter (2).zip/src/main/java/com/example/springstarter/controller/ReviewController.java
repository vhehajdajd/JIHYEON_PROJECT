package com.example.springstarter.controller;

import com.example.springstarter.entity.Book;
import com.example.springstarter.entity.Review;
import com.example.springstarter.service.BookService;
import com.example.springstarter.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDateTime;

/*
    * 리뷰 삭제/등록

        /book/{bookId}/reviews/{reviewId}
        ------------- -------------------
        책 리소스          리뷰 리소스

    * HTML <form>은 method="GET"과 method="POST" 만 지원함
        - <form method="DELETE"> <---- 브라우저가 무시하고 POST으로 보냄

 */

@Controller
@RequiredArgsConstructor
@RequestMapping("/books/{bookId}/reviews")
public class ReviewController {
    private final BookService bookService;
    private final ReviewService reviewService;

    //리뷰 삭제
    @PostMapping("/{reviewId}/delete")
    public String deleteReview(@PathVariable Long bookId, @PathVariable Long reviewId) {
        reviewService.deleteReviewById(reviewId);
        return "redirect:/books/" + bookId +"?deleted=true";    //true =delete가 됨
    }

    /*
        리뷰 등록
        [요청 흐름]
        detail.html에서 리뷰 작성 폼 → POST /books/{bookId}/reviews
        (사용자가 리뷰 내용을 입력하고 제출하면 POST /books/{bookId}/reviews 요청이 발생)
        [처리 순서]
        1) bookId를 받아, DB에서 어떤 책의 리뷰인지 조회 (없으면 예외처리)
        2) review 객체에 book과 생성시간을 세팅
        3) DB에 저장
        4) redirect 처리 + ?registered=true값을 넘김 → detail.html의 JS가 "등록 완료"  alert 표시
        (리다이렉트: 사용자가 요청한 URL을 다른 URL로 자동으로 보내는 것)

     */

    @PostMapping
    public String reviewRegister(@PathVariable  Long bookId, Review review) {
        /*1번*/
        Book book = bookService.getById(bookId)
                .orElseThrow(()-> new IllegalArgumentException("Invalid Book Id" + bookId));
        /*2번*/
        review.setBook(book);
        review.setCreatedAt(LocalDateTime.now());
        /*3번*/
        reviewService.save(review);
        /*4번*/
        return "redirect:/books/" + book.getId() + "?registered=true";
    }

    /*
        리뷰 수정
        [요청 흐름]
        detail.html 인라인 수정 폼 → POST /books/{bookId}/reivews

        [처리 순서]
            1) reviewId로 기존 리뷰를 찾음 (컨트롤러 기준임. 다른 클래스(서비스, 리포지토리)는 역할이 다르기 때문에 처리 순서도 조금씩 다름)
            2) 폼에서 전달받은 content와 rating으로 기존 리뷰를 업데이트
            3) DB에 저장 (JPA의 save()는 id가 있으면 update, 없으면 insert)
            4) redirect + ?edited=true → detail.html의 JS가 "수정 완료" alert 표시해줘야함

        [왜 기존 리뷰를 findById()(서비스의 있는 것)로 먼저 조회하는가?]
            - 폼에서 전달되는 데이터는 content와 rating뿐임
            - book_id, createdAt 등 다른 필드가 null로 덮어씌워지는 것을 방지하기 위함
            - 기존 엔티티를 조회한 후 변경할 필드만 수정하는 것이 안전한 패턴
    */

    @PostMapping("/{reviewId}/edit")
    public String editReview(@PathVariable Long bookId,@PathVariable Long reviewId, Review review) {
        // findById(reviewId)로 DB에서 기존 리뷰를 통째로 불러오기 때문에 null 문제가 없음)
        Review existReview = reviewService.findById(reviewId).orElseThrow(() -> new IllegalArgumentException("Invalid Review Id: " + reviewId));

        //폼에서 넘어온 review 객체는 사용하지 않고, 값만 뽑아서 기존 엔티티에 두 필드만 덮어씀
        existReview.setContent(review.getContent());
        existReview.setRating(review.getRating());

        reviewService.save(existReview);  // id가 있으므로 UPDATE 쿼리 실행

        return "redirect:/books/" +bookId+ "?edited=true";  //PRG 패턴
    }
}

