package com.hometalk.onepass.entity.dashboard;

import jakarta.persistence.*;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AttributeOverrides({
        @AttributeOverride(name = "createdAt", column = @Column(name = "created_at")),
        @AttributeOverride(name = "updatedAt", column = @Column(name = "updated_at"))
})
public class NoticeDashboard {  //클래스명 원상복구하기

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long noticeId;
    private Long userId;
    private String title;
    private LocalDateTime  createdAt;

    @Builder
    public NoticeDashboard(Long id, Long user_id, String title, LocalDateTime created_at) {
        this.noticeId = id;
        this.userId = user_id;
        this.title = title;
        this.createdAt = created_at;
    }
}
