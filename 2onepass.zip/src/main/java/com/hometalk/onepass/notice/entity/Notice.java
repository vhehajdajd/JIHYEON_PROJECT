package com.hometalk.onepass.notice.entity;

import com.hometalk.onepass.entity.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Notice extends BaseTimeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;

    @Column(nullable = false, length = 100)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    private boolean isPinned;

    private int viewCount;

    @Enumerated(EnumType.STRING)
    private Badge badge;
}