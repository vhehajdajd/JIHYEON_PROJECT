package com.hometalk.onepass.notice.dto;


import com.hometalk.onepass.notice.entity.Badge;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NoticeDetailResponseDTO {

    private Long id;
    private Long userId;


    private String title;

    private String content;

    private boolean isPinned;

    private int viewCount;

    private Badge badge;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

}
