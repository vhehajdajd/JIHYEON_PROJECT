package com.hometalk.onepass.schedule.entity;

import com.hometalk.onepass.entity.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Schedule extends BaseTimeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private String targetType;
    private Long targetId;

    @Column(nullable = false, length = 30)
    private String title;

    private String info;
    private String location;
    private String referenceUrl;
    private LocalDateTime startAt;
    private LocalDateTime endAt;
}