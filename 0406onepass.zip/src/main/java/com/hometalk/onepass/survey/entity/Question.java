package com.hometalk.onepass.survey.entity;

import com.hometalk.onepass.entity.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"survey_id", "display_order"}))
public class Question extends BaseTimeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long surveyId;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    private int displayOrder;

    @Column(columnDefinition = "boolean default true")
    private Boolean isRequired;
}