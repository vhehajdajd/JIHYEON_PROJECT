package com.hometalk.onepass.survey.entity;


import com.hometalk.onepass.entity.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Survey extends BaseTimeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 30)
    private String title;

    private String content;
    private int viewCount;

    @Column(columnDefinition = "boolean default false")
    private Boolean isAnonymous;

    private LocalDateTime startAt;
    private LocalDateTime endAt;
}