package com.hometalk.onepass.survey.entity;

import com.hometalk.onepass.entity.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Options extends BaseTimeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long questionId;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    private int optionOrder;
}