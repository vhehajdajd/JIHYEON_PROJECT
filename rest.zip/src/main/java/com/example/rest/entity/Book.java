package com.example.rest.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "book")   //테이블명 명시 --- 클래스명과 테이블명의 매핑을 명확히 드러냄 (보통은 테이블명과 클래스명을 똑같이 씀)
public class Book {
    @Id     //jakarta로 함
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "subject",length = 200) private String subject;   //컬럼 길이 제약 (기본값: 255), 바로 앞에 어노테이션 붙이기 가능
    // PhysicalNamingStrategyStandardImpl 설정 때문에 자동 변환 없으니까 직접 DB 컬럼명 지정
    @Column(name = "price")
    private int price;
    @Column(name = "author", length = 100)
    private String author;
    @Column(name = "page")
    private int page;
    @Column(name = "created_at", updatable = false)    //INSERT 시에만 값 설정, UPDATE 시 변경 불가 // create는 한 번만 됨! (최초 insert 할 때만)
    private LocalDateTime createdAt;    //스네이크 표기법으로 자동 변환 안 됨 (yaml에 그렇게 설정해놓음)
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // 메서드 추가
    @PrePersist //DB에 INSERT 하기 직전에 실행, 최초 저장(INSERT) 직전에 자동 호출
    public void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    // 메서드 추가
    @PreUpdate  //매번 수정(UPDATE)하기 직전에 자동호출 → now로 해야됨 (현재 시간으로 자동 세팅)
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}


