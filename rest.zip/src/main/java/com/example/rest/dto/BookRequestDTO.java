package com.example.rest.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BookRequestDTO {

    // @NotBlank : null, "", " " 모두 거부 (String 전용)
    @NotBlank(message = "책 제목은 필수입니다.")  // 값 입력하지 않았을 때 저 메세지 출력,
    @Schema(description = "책 제목",
            example = "Java와 AI의 미래",   // "Try it out"시 자동으로 채워지는 예시값
            requiredMode = Schema.RequiredMode.REQUIRED)    // Swagger UI에서 빨간 * 필수 표시
    private String subject;

    @NotNull(message = "가격은 필수입니다.") // null만 거부 (숫자 타입은 @NotBlank 불가)
    @Min(value = 0, message = "가격은 0 이상이어야 합니다.")   // 최소값 제한 (음수 방지)
    @Schema(description = "가격 (원)", example = "35000")   // @Schema : Swagger에서 필드 설명 추가
    private Integer price;

    @NotBlank(message = "저자명은 필수입니다.")
    @Schema(description = "저자", example = "이방원")
    private String author;

    @NotNull(message = "페이지 수는 필수입니다.")
    @Min(value = 1, message = "페이지 수는 1 이상이어야 합니다.")
    @Schema(description = "페이지 수", example = "500")
    private Integer page;

}
