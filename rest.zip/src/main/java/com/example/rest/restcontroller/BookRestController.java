package com.example.rest.restcontroller;


import com.example.rest.dto.BookRequestDTO;
import com.example.rest.dto.BookViewDTO;
import com.example.rest.entity.Book;
import com.example.rest.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/*
    Book REST API 컨트롤러

    [REST API 설계 원칙]

    Method            URI                 역할
    ---------------------------------------------------
    POST          /api/books          새 책 등록 (Create)
    GET           /api/books          전체 목록 조회 (Read All)
    GET           /api/books/{id}     단건 조회 (Read One)
    PUT           /api/books/{id}     수정 (Update)
    DELETE        /api/books/{id}     삭제 (Delete)

 */

@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/api")
@Tag(name = "Book Controller", description = "책을 관리하는 컨트롤러")        // Swagger UI 화면에서 API 그룹 제목과 설명으로 표시됨
public class BookRestController {

    private final BookService bookService;


    // Swagger UI: GET /api/test
    @GetMapping("/test")        // HTTP GET 메서드 → Swagger UI에서 파란색 GET 배지
    @Operation(summary = "서버 상태 확인", description = "서버가 정상 동작하는지 확인하는 테스트 엔드포인트")
    @Tag(name = "Health Check")
    public ResponseEntity<String> test() {
        //리턴타입 맞춰줘야함
        return ResponseEntity.ok("Hello REST API Server is running");
    }

    /*
        Swagger UI: POST /api/books -- 초록색 POST 배지

        @Valid → 유효성 검증 (Swagger UI에서 required(필수) 필드 표시에 영향)
                 검증 실패 시 예외 처리가 됨

        @RequestBody → 역할: HTTP 요청 본문(JSON)을 자바 객체로 자동 변환해주는 어노테이션 (역직렬화 : JSON → DTO)
                       Swagger UI에서 "Request Body" 입력 영역이 생성되며
                       BookRequestDTO의 @Schema 정보로 예시 JSON이 자동으로 채워짐
     */

        @PostMapping(value = "/books",
                        consumes = "application/json",  // Swagger UI "Request body" 섹션에 JSON 입력 폼 활성화
                        produces = "application/json")  // Swagger UI "Response" 섹션에 JSON 응답 스키마 표시

        @Operation(summary = "새 책 등록",
                   description = "새로운 책을 등록합니다. id와 createdAt은 서버에서 자동 생성됩니다.")
        @ApiResponses({     // @ ApiResponses - 하나의 엔드포인트가 반환할 수 있는 여러 HTTP 상태 코드를 묶어서 선언
                @ApiResponse(responseCode = "201", description = "등록 성공"),
                @ApiResponse(responseCode = "400", description = "유효성 검증 실패")
        })
        public ResponseEntity<BookViewDTO> createBook(
                @Valid
                @RequestBody
                BookRequestDTO bookRequestDTO) {
            log.info("[Post] /api/books - 신규 등록: {}", bookRequestDTO); // DTO에서 서비스로 가고 있음?
            Book saved = bookService.createBook(bookRequestDTO);
            return ResponseEntity
                    .status(HttpStatus.CREATED)         // 201 created (실무 권장 - 200 대신 201로 함)
                    .body(BookViewDTO.from(saved));     // Entity → DTO 변환
        }

        /* Swagger UI: GET /api/books/{id} -- 파란색 GET 배지 */
        @GetMapping(value = "/books/{id}", produces = "application/json")
        @Operation(summary = "특정 책 조회",
                    description = "ID로 특정 책을 조회합니다. 존재하지 않으면 404를 반환합니다.")
        @ApiResponses({
                @ApiResponse(responseCode = "200", description = "조회 성공"),
                @ApiResponse(responseCode = "404", description = "책을 찾을 수 없음")
        })
        public ResponseEntity<BookViewDTO> getBookById(
                @PathVariable Long id) {
            log.info("[GET] /api/book/{} - 단건 조회", id);
            Book book = bookService.findById(id);
            return ResponseEntity.ok(BookViewDTO.from(book));   // Entity → DTO 변환 + 200번 상태값 OK

        }

        /* Swagger UI: PUT /api/books/{id} -- 주황색 PUT 배지 */

        @PutMapping(value = "/books/{id}",
                    consumes = "application/json",
                    produces = "application/json")
        @Operation(summary = "기존 책 수정",
                    description = "ID에 해당하는 책의 정보를 전체 수정합니다.")
        @ApiResponses({
                @ApiResponse(responseCode = "200", description = "수정 성공"),
                @ApiResponse(responseCode = "404", description = "책을 찾을 수 없음"),
                @ApiResponse(responseCode = "400", description = "유효성 검증 실패")
        })
        public ResponseEntity<BookViewDTO> updateBook(   // 응답 본문 타입 기술 + HTTP 상태 코드를 함께 제어
            @Parameter(description = "수정할 책의 ID", example = "1")
            @PathVariable Long id,
            @Valid @RequestBody BookRequestDTO bookRequestDTO // @Valid -DTO 유효성 검증 // @RequestBody - JSON → DTO 역직렬화 (Jackson)
        ){
            log.info("[PUT] /api/book/{} - 수정: {}", id, bookRequestDTO);
            Book updated = bookService.updateBook(id,bookRequestDTO);
            return ResponseEntity.ok(BookViewDTO.from(updated));    //200 + tnwjdehls epdlxj
        }

        @DeleteMapping(value = "/books/{id}")
        @Operation(summary = "책 삭제",
            description = "ID에 해당하는 책을 삭제합니다.")
        @ApiResponses({
            @ApiResponse(responseCode = "204", description = "삭제 성공"),
            @ApiResponse(responseCode = "404", description = "책을 찾을 수 없음")
        })
        public ResponseEntity<Void> deleteBook(
                @PathVariable Long id) {
            log.info("[DELETE] /api/book/{} - 단건 삭제", id);
            bookService.deleteBook(id);
            return ResponseEntity.noContent().build();
        }

        @GetMapping(value = "/books")
        @Operation(summary = "전체 책 목록 조회",
                    description = "등록된 모든 책을 조회합니다. 목록이 비어있으면 빈 배열을 반환합니다.")
        public ResponseEntity<List<BookViewDTO>> findAll() {        // findAll()은 파라미터가 없기 때문에 괄호가 비어있음
                log.info("[GET] /api/books - 전체 조회");
                List<Book> books = bookService.findAll();
                List<BookViewDTO> result = new ArrayList<>();
                for (Book book : books) {
                    result.add(BookViewDTO.from(book));
                }
                return ResponseEntity.ok(result);
        }


}
