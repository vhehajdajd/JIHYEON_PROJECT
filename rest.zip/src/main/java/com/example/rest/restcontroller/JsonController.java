package com.example.rest.restcontroller;

import com.example.rest.entity.Book;
import com.example.rest.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/*
    JSON 직렬화 테스트 컨트롤러
        - @RestController에서 return할 때
          Jackson이 자동으로 Java 객체를 JSON 타입으로 변환하는 과정을
          확인할 수 있는 API

 */


@Slf4j                           // log.info() 쓸 수 있게 해주는 Lombok 어노테이션
@RestController                  // JSON 반환
@RequestMapping("/api/lab")      // 공통 URL
@Tag(name = "JSON Lab", description = "JSON 직렬화 실습 - Jackson 동작 확인하는 랩") // Swagger에서 그룹 이름 지정
@RequiredArgsConstructor
public class JsonController {

    private final BookService bookService;

    @GetMapping("/Step1-string")                                  // ↓ but jackson까지 안 오고 끝남 (String 타입을 처리할 수 있으니까?)
    @Operation(summary = "[Step1] 문자열 반환", description = "단순 문자열을 return하면 Jackson이 JSON 문자열로 변환합니다." +
                                                            "Response Body에서 쌍따옴표를 감싸진 문자열로 확인하세요.")
    public String step1String(){
        log.info("Step 1: 문자열 반환");   //로거를 통해 출력할 수 있음 (System.out.println() 대신)
        return "Hello World";   // 이 문자열이 Jackson 라이브러리를 거쳐 JSON 응답으로 변환
        // StringHttpMessageConverter가 처리 (Jackson은 관여 안 함)
    }

    @GetMapping("/step2-object")
    @Operation(summary = "[Step 2] 객체 하나 반환 (DB 조회)",
                description = "DB에서 Book 1건을 조회하여 return합니다. " +
                                "Controller → Service → Repository → DB 전체 흐름을 " +
                                "거쳐 Jackson이 JSON 객체 {...}로 변환합니다.")
    public Book step2Object() {
        log.info("Step 2: 객체 하나 반환 (DB 조회)");
        return bookService.findById(1L);
    }

    /*
        리스트 반환 (DB에서 전체 조회)

            Jackson의 타입별 변환 규칙
                Java 타입         JSON 결과
            ----------------------------------
               Book(단일)          { } (객체)
              List<Book>       [ { }, { } ] (배열)
     */
    @GetMapping("/step3-list")
    @Operation(summary = "[Step 3] 리스트 반환 (DB 전체 조회)",
                description = "DB에서 전체 Book 목록을 조회하여 return합니다." +
                                "Jackson이 List를 JSON 배열 [{...}, {...}]로 변환합니다. " )
    public List<Book> step3List() {
        log.info("Step 3: 리스트 반환 (DB 전체 조회)");
        return bookService.findAll();
    }
}
