package com.example.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/*
	Spring Boot 애플리케이션 시작점 (Entry Point)
		@SpringBootApplication은 아래 3개 어노테이션을 합친 것
			- @SpringBootConfiguration - 이 클래스가 설정(Configuration) 클래스임을 선언
			- @EnableAutoConfiguration - 클래스 패스의 라이브러리를 감지해 자동 설정
										 (DataSource, EntityManager 자동 구성)
			- @ComponentScan - 우리 패키지 (com.example.rest) 하위의
					@Controller, @Service, @Repository, @Component를 자동으로 빈 등록
 */
@SpringBootApplication
public class RestApplication {

	public static void main(String[] args) {
		// 내장 톰캣 기능 + 스프링 컨텍스(IOC 컨테이너) 초기화
		SpringApplication.run(RestApplication.class, args);
	}

}
