package com.example.rest.repository;

import com.example.rest.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/*
    JpaRepository<Book, Long>을 상속하면 구현 코드 없이도
    기본 메서드들이 자동 제공됨 (CRUD 메서드)
        - 기본 메서드
            - save(Book)
            - findById(Long)
            - findAll()
            - delete(Book)
            - count()
            - existById(Long)
 */

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

}
