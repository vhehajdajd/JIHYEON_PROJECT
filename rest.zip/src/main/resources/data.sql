/*
    data.sql을 쓰는 이유 : 개발할 때 테스트 데이터를 자동으로 넣기 위해 (수동 insert는 귀찮음)
        - DB에 직접 넣는 거라서 SQL 문법을 써야 함


    insert into book (...)
    select ... where not exist (select 1 from book where subject = 'Java와 AI')
    → subject 값에 조건(Java와 AI)에 대한 데이터가 없을 때 insert해라!

    select 1 : 실제 컬럼 데이터가 필요 없고, "행이 존재하는 지 여부"만 확인할 때 사용하는 구문
               조건에 맞는 행이 있으면 숫자 1을 반환 (값 자체는 의미 없음)
*/


insert into book (subject, price, author, page, created_at, updated_at) /*언제 언더바고 카멜인지 모르겠음*/
select 'Java와 AI', 35000, '이순신', 500, now(), now()
where not exists (select 1 from book where subject = 'Java와 AI');

insert into book (subject, price, author, page, created_at, updated_at)
select 'Spring Boot in Action', 42000, '세종대왕', 300, now(), now()
where not exists (select 1 from book where subject = 'Spring Boot in Action');

insert into book (subject, price, author, page, created_at, updated_at)
select 'Effective Java', 38000, '신사임당', 412, now(), now()
where not exists (select 1 from book where subject = 'Effective Java');
